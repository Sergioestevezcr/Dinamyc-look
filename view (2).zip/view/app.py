from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_file, Response
from flask_mysqldb import MySQL  # Conexión con MySQL
from fpdf import FPDF, HTMLMixin
from werkzeug.security import generate_password_hash, check_password_hash  # Seguridad para contraseñas
from functools import wraps  # Permite crear decoradores personalizados
import os  # Manejo de rutas de archivos
import io
from datetime import datetime, timedelta
import secrets
import string
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # Ruta del directorio base del proyecto

# Crear instancia de la aplicación Flask
app = Flask(__name__,
    template_folder=os.path.join(BASE_DIR, 'templates'),  # Ruta a las plantillas HTML
    static_folder=os.path.join(BASE_DIR, 'static'))  # Ruta a archivos estáticos

# Configuración de base de datos MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'dinamyc_look2'
mysql = MySQL(app)

# Configuración de email
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Cambiar según tu proveedor
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'vargasruizlauravalentina@gmail.com'  # Tu email
app.config['MAIL_PASSWORD'] = 'rjvc vwsr mtuq phzt'   # Contraseña de aplicación de Gmail

# Carpeta donde se guardarán las imágenes
UPLOAD_FOLDER = 'static/imagenes'  
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Clave secreta para proteger la sesión
app.secret_key = 'mysecret_key'

# -------------------------------------- LOGIN -----------------------------------------

# Requiere que el usuario haya iniciado sesión
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página', "info")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Requiere rol administrador
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página', "info")
            return redirect(url_for('login'))
        elif session.get('user_role') != 'Admin':
            flash('No tienes permisos para acceder a esta página', "warning")
            return redirect(url_for('index_cliente'))
        return f(*args, **kwargs)
    return decorated_function

# Requiere rol cliente o administrador
def cliente_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página', "info")
            return redirect(url_for('login'))
        elif session.get('user_role') not in ['Cliente', 'Admin']:
            flash('No tienes permisos para acceder a esta página', "warning")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form.get('correo', '').strip()  # Elimina espacios en blanco
        clave = request.form.get('clave', '').strip()
        
        # Validación básica
        if not correo or not clave:
            flash('Por favor completa todos los campos', "info")
            return render_template('Vista_usuario/login.html')
        
        try:
            cur = mysql.connection.cursor()
            
            # Buscar usuario por correo
            cur.execute('SELECT ID_Usuario, Nombre, Apellido, Correo, Clave, Rol, Estado FROM usuarios WHERE Correo = %s', (correo,))
            user = cur.fetchone()
            cur.close()

            if user:  # Verificar si el usuario existe
                if user[6] == "Activo":
                    print(f"DEBUG - Usuario encontrado: {user[1]} {user[2]}")
                    print(f"DEBUG - Rol del usuario: {user[5]}")

                    clave_bd = user[4] or ''

                    # Verificar la contraseña
                    if check_password_hash(clave_bd, clave):
                        # Login exitoso - configurar sesión
                        session['user_id'] = user[0]
                        session['user_name'] = user[1]
                        session['user_lastname'] = user[2] if user[2] else ''
                        session['user_email'] = user[3]
                        session['user_role'] = user[5]
                        session['user_estado'] = user[6]

                        print(f"DEBUG - Sesión configurada: user_id={session['user_id']}, role={session['user_role']}")

                        flash(f'¡Bienvenido/a {user[1]}!', 'success')

                        # Redirigir según el rol
                        if user[5] == 'Admin':
                            return redirect(url_for('index'))
                        else:
                            return redirect(url_for('index_cliente'))
                    else:
                        # Contraseña incorrecta
                        print("DEBUG - Contraseña incorrecta")
                        flash('Correo o contraseña incorrectos', "error")
                else:
                    # Usuario Inactivo
                    print("DEBUG - Usuario inactivo")
                    flash('Lo sentimos, su cuenta está inactivada.', "error")
            else:
                # Usuario no encontrado
                print("DEBUG - Usuario no encontrado")
                flash('Correo o contraseña incorrectos', "error")

        except Exception as e:
            print(f"DEBUG - Error en login: {str(e)}")
            flash(f'Error en el sistema: {str(e)}', "error")
    
    return render_template('Vista_usuario/login.html')


# -------------- Recuperar contraseña ---------------------

# Función para generar token seguro
def generate_reset_token():
    """Genera un token seguro de 10 caracteres"""
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(5))

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        
        if not email:
            flash('Por favor ingresa tu correo electrónico', 'error')
            return render_template('Vista_usuario/clave_olvidada.html')
        
        try:
            cur = mysql.connection.cursor()
            
            # Verificar si el email existe
            cur.execute('SELECT ID_Usuario, Nombre FROM usuarios WHERE LOWER(Correo) = %s', (email,))
            user = cur.fetchone()
            
            if user:
                # Generar token y fecha de vencimiento (1 hora)
                token = generate_reset_token()
                expires_at = datetime.now() + timedelta(hours=1)
                
                # Insertar token en la base de datos
                cur.execute('''INSERT INTO tokens (ID_UsuarioFK, Token, Vencimiento, Estado, Creacion) 
                                VALUES (%s, %s, %s, %s, NOW())''',
                            (user[0], token, expires_at, 'activo'))
                mysql.connection.commit()

                # ---------------- ENVÍO DE CORREO ----------------
                msg = MIMEMultipart()
                msg['From'] = formataddr(("Dinamyc Look", app.config['MAIL_USERNAME']))
                msg['To'] = email
                msg['Subject'] = 'Recuperación de contraseña - Dinamyc Look'

                body = f"""
                    Hola {user[1]},

                    Has solicitado restablecer tu contraseña. 
                    Haz clic en el siguiente enlace para crear una nueva contraseña (válido por 1 hora):

                    http://localhost:5000/reset_password/{token}

                    Si no solicitaste este cambio, puedes ignorar este mensaje.

                    Atentamente,  
                    El equipo de Dinamyc Look.
                    """
                msg.attach(MIMEText(body, 'plain'))

                try:
                    server = smtplib.SMTP(app.config['MAIL_SERVER'], app.config['MAIL_PORT'])
                    server.starttls()
                    server.login(app.config['MAIL_USERNAME'], app.config['MAIL_PASSWORD'])
                    server.send_message(msg)
                    server.quit()
                    flash('Hemos enviado un enlace de recuperación a tu correo electrónico', 'success')
                except Exception as e:
                    print(f"Error al enviar el correo: {str(e)}")
                    flash('No se pudo enviar el correo. Intenta más tarde.', 'error')

            else:
                # Por seguridad, mostrar el mismo mensaje
                flash('Si el correo existe, recibirás un enlace de recuperación', 'info')
            
            cur.close()
            
        except Exception as e:
            flash(f'Error en el sistema: {str(e)}', 'error')
            print(f"Error en forgot_password: {str(e)}")
    
    return render_template('Vista_usuario/clave_olvidada.html')

@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    try:
        cur = mysql.connection.cursor()

        # Buscar token con estado activo (que no se ha usado)
        cur.execute('''SELECT t.ID_Tokens, u.ID_Usuario, u.Nombre, u.Correo, t.Vencimiento
                        FROM tokens t
                        JOIN usuarios u ON t.ID_UsuarioFK = u.ID_Usuario
                        WHERE t.Token = %s AND t.Estado = %s''', (token, 'activo'))
        data = cur.fetchone()

        if not data:
            flash('El token es inválido o ya fue usado.', 'error')
            return redirect(url_for('login'))

        token_id, user_id, nombre, correo, vencimiento = data

        # Verificar expiración del token
        if datetime.now() > vencimiento:
            flash('El token ha expirado. Solicita uno nuevo.', 'error')
            return redirect(url_for('forgot_password'))

        if request.method == 'POST':
            nueva_clave = request.form['password']
            confirmar_clave = request.form['confirm_password']

            if nueva_clave != confirmar_clave:
                flash('Las contraseñas no coinciden.', 'error')
                return render_template('Vista_usuario/clave_nueva.html', token=token)

            hash_password = generate_password_hash(nueva_clave)

            # Actualizar contraseña del usuario
            cur.execute('UPDATE usuarios SET Clave = %s WHERE ID_Usuario = %s', (hash_password, user_id))

            # Marcar el token como usado
            cur.execute('UPDATE tokens SET Estado = %s WHERE ID_Tokens = %s', ('inactivo', token_id))

            mysql.connection.commit()

            flash('Contraseña actualizada con éxito. Ahora puedes iniciar sesión.', 'success')
            return redirect(url_for('login'))

        return render_template('Vista_usuario/clave_nueva.html', token=token)

    except Exception as e:
        print(f"Error en reset_password: {str(e)}")
        flash('Ocurrió un error. Intenta nuevamente.', 'error')
        return redirect(url_for('forgot_password'))


# Función para verificar estado de tokens (útil para debug)
@app.route('/admin/token_status')
@admin_required
def token_status():
    """Muestra el estado de todos los tokens"""
    cur = mysql.connection.cursor()
    cur.execute('''SELECT t.ID_Tokens, u.Nombre, u.Correo, t.Token, 
                        t.Vencimiento, t.Estado, t.Creacion
                    FROM tokens t
                    JOIN usuarios u ON t.ID_UsuarioFK = u.ID_Usuario
                    ORDER BY t.Creacion DESC
                    LIMIT 50''')
    tokens = cur.fetchall()
    cur.close()
    
    return render_template('Vistas_admin/token_status.html', tokens=tokens)

# -------------- Registro ---------------------

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    # Maneja el formulario de registro de usuarios
    if request.method == 'POST':
        nombre = request.form['Nombre']
        apellido = request.form['Apellido']
        correo = request.form['Correo']
        confirmar_correo = request.form['Confirmar_correo']
        telefono = request.form['Telefono']
        direccion = request.form['Direccion']
        ciudad = request.form['Ciudad']
        clave = request.form['Clave']
        confirmar_clave = request.form['Confirmar_clave']
        
        if not all([nombre, apellido, correo, confirmar_correo, telefono, direccion, ciudad, clave, confirmar_clave]):
            flash('Completa todos los campos', "info")
            return render_template('Vista_usuario/register.html')
        
        if correo != confirmar_correo:
            flash('Los correos no coinciden', "error")
            return render_template('Vista_usuario/register.html')
        

        if clave != confirmar_clave:
            flash('Las contraseñas no coinciden', "error")
            return render_template('Vista_usuario/register.html')
        
        if len(clave) < 6:
            flash('Contraseña muy corta', "error")
            return render_template('Vista_usuario/register.html')
        
        if len(telefono) < 10: 
            flash('Telefono no valido', "error")
            return render_template('Vista_usuario/register.html')
        
        if len(telefono) >= 11: 
            flash('Telefono no valido', "error")
            return render_template('Vista_usuario/register.html')
        
        try:
            cur = mysql.connection.cursor()
            # Validar correo único
            cur.execute('SELECT ID_Usuario FROM usuarios WHERE Correo = %s', (correo,))
            if cur.fetchone():
                flash('Correo ya registrado', "error")
                cur.close()
                return render_template('Vista_usuario/register.html')
            
            # Guardar nueva cuenta con contraseña cifrada
            hashed_password = generate_password_hash(clave)
            cur.execute('''INSERT INTO usuarios (Nombre, Apellido, Correo, Telefono, Direccion, Ciudad, Clave, Rol) 
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)''',
                        (nombre, apellido, correo, telefono, direccion, ciudad, hashed_password, 'Cliente'))
            mysql.connection.commit()
            cur.close()
            
            flash('¡Registro exitoso!', "success")
            return redirect(url_for('login'))
        except Exception as e:
            flash(f'Error: {str(e)}', "error")
    
    return render_template('Vista_usuario/register.html')

# -------------- logout ---------------------

@app.route('/logout')
@login_required
def logout():
    # Elimina los datos de sesión y clave_nuevarige al login
    user_name = session.get('user_name', 'Usuario')
    session.clear()
    flash(f'¡Hasta pronto {user_name}!', "info")
    return redirect(url_for('login'))


#-------------------------------------------------------------------------------------------------------
#                                      CONEXIÓN VISTAS DEL CLIENTE
#-------------------------------------------------------------------------------------------------------
@app.route('/index_cliente')
def index_cliente():
    user_id = session.get("user_id")   # ID del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()

    # Productos (máximo 8)
    cur.execute('call seleccionarprodindex()')
    data = cur.fetchall()

    favoritos = []

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("CALL favoritosp(%s)", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/index.html', 
                            productos2=data,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre
                        )

@app.route('/epa_colombia')
def epa_colombia():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "EPA Colombia"''')
    data = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/epa-colombia.html', 
                            productosepa=data,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/anyeluz')
def anyeluz():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "Anyeluz"''')
    data = cur.fetchall()

    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "Anyeluz"
                    LIMIT 6''')
    datalim = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/anyeluz.html', 
                            productosanyeluz=data,
                            productosanyeluzlim=datalim,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/milagros')
def milagros():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "Milagros"''')
    data = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/milagros.html', 
                            productosmilagros=data,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/dluchi')
def dluchi():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "D’Luchi"''')
    data = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/dluchi.html', 
                            productosdluchi=data,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/kaba')
def kaba():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "Kaba"''')
    data = cur.fetchall()

    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "Kaba" LIMIT 6''')
    datalim = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/kaba.html', 
                            productoskaba=data,
                            productoskabalim=datalim,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/la_receta')
def la_receta():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "La Receta"''')
    data = cur.fetchall()

    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "La Receta" LIMIT 6''')
    datalim = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/lareceta.html', 
                            productosreceta=data,
                            productosrecetalim=datalim,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/magic_hair')
def magic_hair():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "Magic Hair"''')
    data = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/magic-hair.html', 
                            productosmagic=data,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/OMG')
def OMG():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "OMG"''')
    data = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/OMG.html', 
                            productosOMG=data,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/la_pocion')
def la_pocion():
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "La Poción"''')
    data = cur.fetchall()

    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE prov.Marca = "La Poción" LIMIT 6''')
    datalim = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    return render_template('Vista_usuario/la-pocion.html', 
                            productospocion=data,
                            productospocionlim=datalim,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

@app.route('/conocenos')
def conocenos():
    return render_template('Vista_usuario/conocenos.html')

# -------------------------------------- FAVORITOS -----------------------------------------

@app.route("/toggle_favorito/<int:producto_id>", methods=["POST"])
def toggle_favorito(producto_id):
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"success": False, "error": "No autenticado"}), 401

    cursor = mysql.connection.cursor()

    # Verificar si ya existe
    cursor.execute("SELECT * FROM favoritos WHERE ID_UsuarioFK = %s AND ID_ProductoFK = %s", (user_id, producto_id))
    favorito = cursor.fetchone()

    if favorito:
        # Quitar de favoritos
        cursor.execute("DELETE FROM favoritos WHERE ID_UsuarioFK = %s AND ID_ProductoFK = %s", (user_id, producto_id))
        mysql.connection.commit()
        cursor.close()
        return jsonify({"success": True, "favorito": False})
    else:
        # Agregar a favoritos
        cursor.execute("INSERT INTO favoritos (ID_UsuarioFK, ID_ProductoFK) VALUES (%s, %s)", (user_id, producto_id))
        mysql.connection.commit()
        cursor.close()
        return jsonify({"success": True, "favorito": True})

# -------------------------------------- DETALLES PRODUCTO -----------------------------------------

@app.route("/detallesproducto/<int:id>")
def detallesproducto(id):
    user_id = session.get("user_id")   # este es el id del usuario en sesión
    user_name = session.get("user_name")

    cur = mysql.connection.cursor()
    cur.execute("""SELECT 
                    p.ID_Producto, 
                    p.Nombre, 
                    p.Descripcion, 
                    p.Precio, 
                    p.Imagen, 
                    prov.Marca AS Marca
                FROM productos p
                JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                WHERE p.ID_Producto = %s""", (id,))
    productodetalles = cur.fetchone()

    cur.execute(""" SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    WHERE p.ID_Producto != %s
                    AND prov.Marca = (
                            SELECT prov.Marca
                            FROM productos p2
                            JOIN proveedores prov2 ON p2.ID_ProveedorFK = prov2.ID_Proveedor
                            WHERE p2.ID_Producto = %s
                        )
                    ORDER BY RAND()
                    LIMIT 4;""", (id, id,))
    relacionados = cur.fetchall()

    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca AS Marca
                    FROM productos p
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    ORDER BY RAND() LIMIT 9''')
    caruseldetalles = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        favoritos = [row[0] for row in cur.fetchall()]
    cur.close()

    if not productodetalles:
        return "Producto no encontrado", 404

    return render_template("Vista_usuario/info_producto.html", 
                            productodetalles=productodetalles, 
                            relacionados=relacionados,
                            caruseldetalles=caruseldetalles,
                            user=user_name,
                            favoritos=favoritos,
                            nombre=nombre)

# -------------------------------------- CARRITO -----------------------------------------

@app.route("/carrito_get")
def carrito_get():
    user_id = session.get("user_id")
    if user_id:
        cur = mysql.connection.cursor()
        cur.execute("SELECT ID_Carrito, Producto, Precio, Cantidad, Imagen FROM carrito_temp WHERE ID_UsuarioFK = %s", (user_id,))
        rows = cur.fetchall()
        cur.close()
        carrito = [{"id": r[0], "nombre": r[1], "precio": r[2], "cantidad": r[3], "img": r[4]} for r in rows]
    else:
        carrito = session.get("carrito", [])
        # darle un id ficticio basado en índice
        for idx, item in enumerate(carrito):
            item["id"] = idx
    return jsonify(carrito)


# 1. Agregar producto al carrito (si existe, aumenta cantidad)
@app.route("/carrito_agregar", methods=["POST"])
def carrito_agregar():
    data = request.form
    producto = data["nombre"]
    precio = float(data["precio"])
    cantidad = int(data["cantidad"])
    img = data.get("img", "")

    user_id = session.get("user_id")

    if user_id:  
        cur = mysql.connection.cursor()

        # Verificar si ya existe el producto en el carrito
        cur.execute("""
            SELECT ID_Carrito, Cantidad 
            FROM carrito_temp 
            WHERE ID_UsuarioFK = %s AND Producto = %s
        """, (user_id, producto))
        existente = cur.fetchone()

        if existente:
            # Si existe, solo actualizamos la cantidad
            nuevo_total = existente[1] + cantidad
            cur.execute("""
                UPDATE carrito_temp 
                SET Cantidad = %s 
                WHERE ID_Carrito = %s
            """, (nuevo_total, existente[0]))
        else:
            # Si no existe, lo insertamos
            cur.execute("""
                INSERT INTO carrito_temp (ID_UsuarioFK, Producto, Precio, Cantidad, Imagen)
                VALUES (%s, %s, %s, %s, %s)
            """, (user_id, producto, precio, cantidad, img))

        mysql.connection.commit()
        cur.close()

    else:  
        carrito = session.get("carrito", [])
        encontrado = False
        for item in carrito:
            if item["nombre"] == producto:
                item["cantidad"] += cantidad
                encontrado = True
                break

        if not encontrado:
            carrito.append({"nombre": producto, "precio": precio, "cantidad": cantidad, "img": img})

        session["carrito"] = carrito

    flash("Producto agregado al carrito", "success")
    return redirect(url_for("index_cliente"))

# ==================== Actualizar cantidad exacta en carrito ====================
@app.route("/carrito_actualizar", methods=["POST"])
def carrito_actualizar():
    data = request.form
    item_id = data.get("id")
    cantidad = int(data.get("cantidad", 1))
    if cantidad < 1:
        cantidad = 1

    user_id = session.get("user_id")

    if user_id:
        cur = mysql.connection.cursor()
        # Actualizar cantidad exacta del producto en la base de datos
        cur.execute("""
            UPDATE carrito_temp
            SET Cantidad = %s
            WHERE ID_Carrito = %s AND ID_UsuarioFK = %s
        """, (cantidad, item_id, user_id))
        mysql.connection.commit()
        cur.close()
    else:
        # Si no hay usuario logueado, actualizar en la sesión
        carrito = session.get("carrito", [])
        item_id = int(item_id)  # ID ficticio basado en índice
        if 0 <= item_id < len(carrito):
            carrito[item_id]["cantidad"] = cantidad
        session["carrito"] = carrito

    return jsonify({"success": True, "cantidad": cantidad})


# 2. Eliminar producto
@app.route("/carrito_eliminar/<item_id>", methods=["POST"])
def carrito_eliminar(item_id):
    user_id = session.get("user_id")

    if user_id:  
        cur = mysql.connection.cursor()
        cur.execute("DELETE FROM carrito_temp WHERE ID_Carrito = %s AND ID_UsuarioFK = %s", (item_id, user_id))
        mysql.connection.commit()
        cur.close()
    else:  
        item_id = int(item_id)
        carrito = session.get("carrito", [])
        if 0 <= item_id < len(carrito):  # usamos el índice de la lista
            carrito.pop(item_id)
        session["carrito"] = carrito

    return redirect(url_for("index_cliente"))

@app.route("/carrito_finalizar", methods=["POST"])
@login_required
def carrito_finalizar():
    user_id = session["user_id"]
    cur = mysql.connection.cursor()

    # Tomar productos del carrito (BD o sesión)
    carrito = cur.execute("SELECT Producto, Precio, Cantidad FROM carrito_temp WHERE ID_UsuarioFK = %s", (user_id,))
    carrito = cur.fetchall()
    
    if not carrito:  # Si no hay en BD, tomar de sesión
        carrito = session.get("carrito", [])
        if not carrito:
            flash("Tu carrito está vacío", "danger")
            return redirect(url_for("index_cliente"))

    # Calcular total
    total = sum([item[1] * item[2] if isinstance(item, tuple) else item["precio"] * item["cantidad"] for item in carrito])

    # Insertar venta
    cur.execute("INSERT INTO ventas (ID_UsuarioFK, Fecha, Total) VALUES (%s, NOW(), %s)", (user_id, total))
    id_venta = cur.lastrowid  # Obtenemos el ID de la venta recién creada

    # Insertar detalles
    for item in carrito:
        if isinstance(item, tuple):  # desde BD
            nombre, precio, cantidad = item
        else:  # desde sesión
            nombre, precio, cantidad = item["nombre"], item["precio"], item["cantidad"]
        
        # Aquí debes obtener ID_ProductoFK a partir del nombre
        cur.execute("SELECT ID_Producto FROM productos WHERE Nombre = %s", (nombre,))
        id_producto = cur.fetchone()[0]

        cur.execute("""
            INSERT INTO detalles_venta (ID_VentaFK, ID_ProductoFK, Cantidad_p, SubTotal)
            VALUES (%s, %s, %s, %s)
        """, (id_venta, id_producto, cantidad, precio * cantidad))

    # Limpiar carrito
    cur.execute("DELETE FROM carrito_temp WHERE ID_UsuarioFK = %s", (user_id,))
    session.pop("carrito", None)

    mysql.connection.commit()
    cur.close()

    flash("Compra finalizada con éxito", "success")
    return redirect(url_for("index_cliente"))

# -------------------------------------- COMPRAS -----------------------------------------

@app.route('/compras')
@cliente_required
def compras():
    user_id = session.get("user_id")

    cur = mysql.connection.cursor()
    cur.execute('''
        SELECT
            Num_venta,
            Fecha,
            SUM(SubTotal_Final) AS Total_Comprado,
            SUM(Cantidad_p) AS Total_Productos
        FROM reporte
        WHERE ID_cliente = %s
        GROUP BY Num_venta, Fecha
        ORDER BY Num_venta DESC
    ''', (user_id,))
    
    data = cur.fetchall()
    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None
    cur.close()

    return render_template("Vista_usuario/compras.html", 
                            compras=data, 
                            nombre=nombre)

# -------------------------------------- FAVORITOS -----------------------------------------
@app.route('/fovoritos')
@cliente_required
def favoritos():
    user_id = session.get("user_id")

    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                        p.ID_Producto, 
                        p.Nombre, 
                        p.Precio, 
                        p.Imagen, 
                        prov.Marca
                    FROM Productos p
                    INNER JOIN favoritos f 
                        ON p.ID_Producto = f.ID_ProductoFK 
                        AND f.ID_UsuarioFK = %s
                    INNER JOIN proveedores prov 
                        ON p.ID_ProveedorFK = prov.ID_Proveedor
                    ORDER BY prov.Marca ASC;''', (user_id,))
    
    data = cur.fetchall()

    # Solo si el usuario tiene sesión activa
    if user_id:
        # Nombre desde la BD
        cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
        row = cur.fetchone()
        nombre = row[0] if row else None

        # Favoritos desde la BD
        cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
        productosfav = [row[0] for row in cur.fetchall()]

    cur.close()

    return render_template("Vista_usuario/favoritos.html", 
                            favoritos=data,
                            productosfav=productosfav,
                            nombre=nombre)

# -------------------------------------- BUSCAR -----------------------------------------

@app.route('/buscar', methods=['GET'])
def buscar():
    user_id = session.get("user_id")
    user_name = session.get("user_name")

    # Obtener parámetros con valores por defecto
    query = request.args.get("q", "").strip()
    categoria = request.args.get("categoria", "")
    subcategoria = request.args.get("subcategoria", "")
    precio_min = request.args.get("precio_min", type=int)
    precio_max = request.args.get("precio_max", type=int)

    cur = mysql.connection.cursor()

    try:
        #  Caso 1: No hay filtros → traer todos los productos
        if not (query or categoria or subcategoria or precio_min or precio_max):
            cur.execute("""
                SELECT 
                    p.ID_Producto,
                    p.Nombre,
                    p.Precio,
                    p.Imagen,
                    prov.Marca AS Marca,
                    p.Categoria
                FROM productos p
                JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                ORDER BY precio ASC
            """)
            resultados = cur.fetchall()

        else:
            # Caso 2: Sí hay filtros → construir consulta dinámica
            base_sql = """
                SELECT 
                    p.ID_Producto,
                    p.Nombre,
                    p.Precio,
                    p.Imagen,
                    prov.Marca AS Marca,
                    p.Categoria
                FROM productos p
                JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
            """

            where_conditions = []
            filtros = []

            # Filtro búsqueda libre
            if query:
                where_conditions.append("""
                    (LOWER(p.Nombre) LIKE %s OR 
                    LOWER(p.Categoria) LIKE %s OR 
                    LOWER(prov.Marca) LIKE %s OR
                    LOWER(p.Descripcion) LIKE %s)
                """)
                query_param = f"%{query.lower()}%"
                filtros.extend([query_param] * 4)

            # Filtro por categoría
            if categoria:
                where_conditions.append("categoria = %s")
                filtros.append(categoria)

            # Filtro por subcategoría
            if subcategoria and subcategoria not in ["", "todas_las_subcategorías"]:
                subcategoria_mapping = {
                    "shampoo": ["shampoo", "champú"],
                    "acondicionador": ["acondicionador"],
                    "tratamiento": ["tratamiento", "mascarilla", "ampolla"],
                    "crema": ["crema", "loción"],
                    "bloqueador_solar": ["bloqueador", "protector solar", "SPF"],
                    "bronceador": ["bronceador", "autobronceante"],
                    "exfoliante": ["exfoliante", "scrub", "peeling"]
                }

                if subcategoria.lower() in subcategoria_mapping:
                    terms = subcategoria_mapping[subcategoria.lower()]
                    condition = " OR ".join(["LOWER(p.nombre) LIKE %s"] * len(terms))
                    where_conditions.append(f"({condition})")
                    filtros.extend([f"%{t}%" for t in terms])
                else:
                    where_conditions.append("LOWER(p.nombre) LIKE %s")
                    filtros.append(f"%{subcategoria.lower().replace('_', ' ')}%")

            # Filtros de precio
            if precio_min is not None and precio_min > 0:
                where_conditions.append("precio >= %s")
                filtros.append(precio_min)

            if precio_max is not None and precio_max > 0:
                where_conditions.append("precio <= %s")
                filtros.append(precio_max)

            if precio_min and precio_max and precio_min > precio_max:
                flash("El precio mínimo no puede ser mayor al precio máximo", "error")
                precio_min, precio_max = precio_max, precio_min

            # Construcción del WHERE
            where_clause = ""
            if where_conditions:
                where_clause = " WHERE " + " AND ".join(where_conditions)

            # Consulta final
            final_sql = f"""
                {base_sql}
                {where_clause}
                ORDER BY 
                    CASE WHEN LOWER(p.nombre) LIKE %s THEN 1 ELSE 2 END,
                    precio ASC
            """

            # Parámetro del CASE
            if query:
                filtros.append(f"%{query.lower()}%")
            else:
                filtros.append("%%")  # '%%' → match siempre

            cur.execute(final_sql, filtros)
            resultados = cur.fetchall()

        # Obtener favoritos del usuario
        productobusf = []
        # Solo si el usuario tiene sesión activa
        if user_id:
            # Favoritos desde la BD
            cur.execute("SELECT ID_ProductoFK FROM favoritos WHERE ID_UsuarioFK = %s", (user_id,))
            productobusf = [row[0] for row in cur.fetchall()]
            total_productos = len(resultados)

            # Nombre desde la BD
            cur.execute("SELECT Nombre FROM Usuarios WHERE ID_Usuario = %s", (user_id,))
            row = cur.fetchone()
            nombre = row[0] if row else None

        if total_productos == 0:
            resultado_mensaje = "No se encontraron productos."
        elif total_productos == 1:
            resultado_mensaje = "Se encontró 1 producto."
        else:
            resultado_mensaje = f"Se encontraron {total_productos} productos."

        return render_template("Vista_usuario/buscar.html",
                                resultados=resultados,
                                query=query,
                                categoria=categoria,
                                subcategoria=subcategoria,
                                precio_min=precio_min,
                                precio_max=precio_max,
                                productobusf=productobusf,
                                user=user_name,
                                total_productos=total_productos,
                                resultado_mensaje=resultado_mensaje,
                                nombre=nombre)

    except Exception as e:
        print(">>> ERROR SQL:", str(e))
        app.logger.error(f"Error en búsqueda: {str(e)}")
        flash("Error al realizar la búsqueda. Por favor, inténtalo de nuevo.", "error")

        return render_template("Vista_usuario/buscar.html",
                                resultados=[],
                                query=query,
                                categoria=categoria,
                                subcategoria=subcategoria,
                                productobusf=[],
                                total_productos=0,
                                resultado_mensaje="Error en la búsqueda.",
                                nombre=nombre)
    finally:
        cur.close()

#-------------------------------------------------------------------------------------------------------
#                                      CONEXIÓN VISTAS DEL ADMIN
#-------------------------------------------------------------------------------------------------------

@app.route('/')
@admin_required
def index():
    """Dashboard principal para administradores"""
    cur = mysql.connection.cursor()
    cur.execute('''SELECT 
                    COUNT(ID_Venta) AS Ventas_Totales, 
                    SUM(Total) AS Ingresos_Totales
                    FROM ventas
                    WHERE MONTH(Fecha) = MONTH(CURDATE())
                    AND YEAR(Fecha) = YEAR(CURDATE())''')
    data_ventas = cur.fetchall()
    
    if data_ventas:
        ventas = data_ventas[0][0] or 0
        ingresos = data_ventas[0][1] or 0
    else:
        ventas = 0
        ingresos = 0


    cur.execute('''SELECT SUM(detalles_venta.Cantidad_p) AS Total_Cantidad_Mes_Actual
                    FROM Detalles_venta 
                    JOIN ventas ON detalles_venta.ID_VentaFK = ventas.ID_Venta
                    WHERE MONTH(ventas.Fecha) = MONTH(CURDATE())
                    AND YEAR(ventas.Fecha) = YEAR(CURDATE())''')
    productosT = cur.fetchone()[0]

    cur.execute('''SELECT 
                        p.Nombre AS Producto,
                        prov.Marca,
                        SUM(dv.Cantidad_p) AS Total_Ventas
                    FROM detalles_venta dv
                    JOIN productos p ON dv.ID_ProductoFK = p.ID_Producto
                    JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
                    GROUP BY p.ID_Producto, prov.Marca
                    ORDER BY Total_Ventas DESC
                    LIMIT 10;
                    ''')
    masVendidos = cur.fetchall()

    cur.execute('SELECT * FROM prductosxacabar ORDER BY prductosxacabar.Stock DESC LIMIT 10')
    xacabar = cur.fetchall()

    cur.close()

    return render_template('Vistas_admin/index-admin.html', 
                        ventas=ventas,
                        ingresos=ingresos,
                        productosT=productosT,
                        vendidos=masVendidos,
                        acabados=xacabar,
                        admin_name=session.get('user_name'))

    # -------------- Datos para la grafica ---------------------

@app.route('/ventas_por_mes')
def ventas_por_mes():
    # Creamos listas con 12 posiciones (una por cada mes)
    ingresos_mensuales = [0] * 12
    ventas_mensuales = [0] * 12
    meses = ['Ene.', 'Feb.', 'Mar.', 'Abr.', 'May.', 'Jun.',
                'Jul.', 'Ago.', 'Sep.', 'Oct.', 'Nov.', 'Dic.']

    # Consulta para obtener ventas y sumatoria de ingresos por mes
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT MONTH(Fecha) AS mes, 
                SUM(Total) AS total_ingresos,
                COUNT(*) AS total_ventas
        FROM ventas
        GROUP BY mes
        ORDER BY mes
    """)
    resultados = cur.fetchall()
    cur.close()

    # Llenamos los arrays con los datos obtenidos
    for fila in resultados:
        mes_idx = int(fila[0]) - 1  # Restamos 1 para que encaje con la posición en la lista
        ingresos_mensuales[mes_idx] = int(fila[1]) if fila[1] else 0
        ventas_mensuales[mes_idx] = int(fila[2]) if fila[2] else 0

    return jsonify({
        'labels': meses[:datetime.now().month],  # Solo hasta el mes actual
        'dataIngresos': ingresos_mensuales[:datetime.now().month],
        'dataVentas': ventas_mensuales[:datetime.now().month]
    })
# -------------------------------------- PRODUCTOS -----------------------------------------

@app.route('/productos')
@admin_required
def productos():
    cur = mysql.connection.cursor()

    # Productos con su precio final
    cur.execute('''
        SELECT 
            p.ID_Producto, 
            p.Nombre, 
            p.Descripcion, 
            p.Imagen, 
            p.Precio AS precio_original,
            p.Stock, 
            prov.Marca AS Marca,
            p.Categoria,
            pr.ID_Promocion,
            pr.Descuento,
            CASE
                WHEN pr.Fecha_Inicial <= CURDATE() 
                    AND pr.Fecha_Final >= CURDATE()
                    AND pr.Descuento IS NOT NULL
                THEN p.Precio - (p.Precio * pr.Descuento / 100)
                ELSE NULL
            END AS precio_final
        FROM productos p
        LEFT JOIN promociones pr ON p.ID_PromocionFK = pr.ID_Promocion
        LEFT JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor;''')
    productos = cur.fetchall()

    # Lista de promociones para el <select>
    cur.execute('''SELECT 
                    ID_Promocion, 
                    Descuento, 
                    Fecha_Inicial, 
                    Fecha_Final
                    FROM promociones
                    WHERE Fecha_Inicial > CURDATE()   -- solo promociones que aún no empiezan
                    ORDER BY Fecha_Inicial ASC''')
    promociones = cur.fetchall()

    cur.execute('SELECT ID_Proveedor, Marca FROM proveedores')
    marcas = cur.fetchall()
    cur.close()


    return render_template("Vistas_admin/productos.html", 
                            productos=productos, 
                            promociones=promociones,
                            marcas=marcas)


@app.route('/add_producto', methods=['POST'])
@admin_required
def add_producto():
    if request.method == 'POST':  
        nombre = request.form['Nombre']
        descripcion = request.form['Descripcion']
        precio = request.form['Precio']
        id_proveedor = request.form.get('ID_ProveedorFK')
        stock = request.form['Stock']
        id_promocion = request.form.get('ID_PromocionFK') or None  # si viene vacío, queda NULL

        # Obtener marca según proveedor
        cur = mysql.connection.cursor()
        cur.execute("SELECT Marca FROM proveedores WHERE ID_Proveedor = %s", (id_proveedor,))
        marca_row = cur.fetchone()
        marca = marca_row[0] if marca_row else "SinMarca"

        # Manejo de archivo
        file = request.files.get('Imagen')
        filename = None
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            folder_name = marca.replace(" ", "_") 
            folder_path = os.path.join(app.config['UPLOAD_FOLDER'], folder_name)
            os.makedirs(folder_path, exist_ok=True)
            file.save(os.path.join(folder_path, filename))
            filename = f"{folder_name}/{filename}"  # sin la barra inicial

        # Insertar producto
        cur.execute('''INSERT INTO productos 
                (Nombre, Descripcion, Precio, Stock, Imagen, ID_PromocionFK, ID_ProveedorFK) 
                VALUES (%s, %s, %s, %s, %s, %s, %s)''',
            (nombre, descripcion, precio, stock, filename, id_promocion, id_proveedor))
        mysql.connection.commit()
        flash('Producto agregado correctamente', "success")
        return redirect(url_for('productos'))

@app.route('/edit_producto/<id>')
def edit_producto(id):
    cur = mysql.connection.cursor()
    cur.execute('''
        SELECT 
            p.ID_Producto, 
            p.Nombre, 
            p.Descripcion, 
            p.Precio, 
            p.Stock, 
            p.Imagen,
            p.ID_PromocionFK,
            p.ID_ProveedorFK,
            prov.Marca
        FROM productos p
        JOIN proveedores prov ON p.ID_ProveedorFK = prov.ID_Proveedor
        WHERE p.ID_Producto = %s
    ''', (id,))
    
    data = cur.fetchone()
    if data:
        product_data = {
            'id': data[0],
            'nombre': data[1],
            'descripcion': data[2], 
            'precio': data[3],
            'stock': data[4],
            'imagen': data[5],
            'id_promocion': data[6],
            'id_proveedor': data[7],
            'marca': data[8]  # <- ahora sí es el nombre real de la marca
        }
        return jsonify(product_data)
    return jsonify({'error': 'Producto no encontrado'}), 404

def allowed_file(filename):
    return '.' in filename and \
            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/update_producto/<id>', methods=['POST'])
def update_producto(id):
    if request.method == 'POST':
        nombre = request.form['Nombre']
        descripcion = request.form['Descripcion']
        precio = request.form['Precio']
        id_proveedor = request.form.get('ID_ProveedorFK')
        stock = request.form['Stock']
        id_promocion = request.form.get('ID_PromocionFK') or None  

        # Buscar marca después de obtener el proveedor
        cur = mysql.connection.cursor()
        cur.execute("SELECT Marca FROM proveedores WHERE ID_Proveedor = %s", (id_proveedor,))
        marca_row = cur.fetchone()
        marca = marca_row[0] if marca_row else "SinMarca"

        # Manejo del archivo
        file = request.files.get('Imagen')
        filename = None
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(file.filename)

            folder_name = marca.lower().replace(" ", "_")
            folder_path = os.path.join(app.config['UPLOAD_FOLDER'], folder_name)
            os.makedirs(folder_path, exist_ok=True)

            file.save(os.path.join(folder_path, filename))
            filename = f"{folder_name}/{filename}"  # sin la barra inicial

        # Actualización en la BD
        if filename:
            cur.execute('''UPDATE productos 
                        SET Nombre=%s, Descripcion=%s, Precio=%s, 
                            Stock=%s, Imagen=%s, ID_PromocionFK=%s, ID_ProveedorFK=%s
                        WHERE ID_Producto=%s''',
                        (nombre, descripcion, precio, stock, filename, id_promocion, id_proveedor, id))
        else:
            cur.execute('''UPDATE productos 
                        SET Nombre=%s, Descripcion=%s, Precio=%s, 
                            Stock=%s, ID_PromocionFK=%s, ID_ProveedorFK=%s
                        WHERE ID_Producto=%s''',
                        (nombre, descripcion, precio, stock, id_promocion, id_proveedor, id))

        mysql.connection.commit()
        flash('Producto actualizado correctamente', "success")
        return redirect(url_for('productos'))

# -------------------------------------- PROMOCIONES/DESCUENTOS ----------------------------------------

@app.route('/promociones')
@admin_required
def promociones():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM promociones ORDER BY fecha_Inicial DESC')
    data = cur.fetchall()

    # Lista de promociones para el <select>
    cur.execute('''SELECT * FROM 
                    promociones
                    WHERE Fecha_Inicial > CURDATE()   -- solo promociones que aún no empiezan
                    ORDER BY Fecha_Inicial ASC''')
    promocionesf = cur.fetchall()

    cur.execute('SELECT ID_Producto, Nombre, Precio FROM productos WHERE Stock > 0')
    productospromo = cur.fetchall()
    cur.close()

    # Pasar datos ya modificados a la plantilla
    return render_template('Vistas_admin/descuentos.html', 
                            promocionesp=data,
                            promocionesf=promocionesf,
                            productospromo=productospromo)

@app.route('/add_promocion', methods=['POST'])
@admin_required
def add_promocion():
    descuento = request.form['Descuento']
    fechai = request.form['Fecha_Inicial']
    fechaf = request.form['Fecha_Final']

    cur = mysql.connection.cursor()
    cur.execute('''INSERT INTO promociones (Descuento, Fecha_Inicial, Fecha_Final)
                    VALUES (%s, %s, %s)''', (descuento, fechai, fechaf))
    mysql.connection.commit()
    cur.close()
    flash('Promoción agregada correctamente', "success")
    return redirect(url_for('promociones'))

    
@app.route('/edit_promocion/<id>')
def edit_promociones(id):
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM promociones WHERE id_promocion = %s', (id,)) 
    data = cur.fetchone()
    if data:
        user_data = {
            'id': data[0],
            'descuento': data[1],
            'fechai': data[2], 
            'fechaf': data[3] 
        }
        return jsonify(user_data)
    return jsonify({'error': 'Usuario no encontrado'}), 404

@app.route('/update_promocion/<id>', methods=['POST'])
def update_promociones(id):
    if request.method == 'POST':
        descuento = request.form['Descuento']
        fechai = request.form['Fecha_Inicial']
        fechaf = request.form['Fecha_Final']

        cur = mysql.connection.cursor()
        cur.execute('''UPDATE promociones 
                        SET Descuento = %s, Fecha_Inicial = %s, Fecha_Final = %s
                        WHERE id_promocion = %s''',
                        (descuento, fechai, fechaf, id))
        mysql.connection.commit()
        flash('Promoción actualizado correctamente', "success")
        return redirect(url_for('promociones'))

@app.route("/asignar_promocion", methods=["POST"])
def asignar_promocion():
    promocion_id = request.form.get("ID_PromocionFK")   # ID de la promo seleccionada
    productos_ids = request.form.getlist("productos[]") # lista de IDs de productos

    if not productos_ids:
        flash("No seleccionaste productos", "warning")
        return redirect(url_for("promociones"))

    cur = mysql.connection.cursor()

    if not promocion_id:
        # Quitar cualquier promoción
        query = "UPDATE productos SET ID_PromocionFK = NULL WHERE ID_Producto IN %s"
        cur.execute(query, (tuple(productos_ids),))
        mysql.connection.commit()
        cur.close()
        flash("Se quitó la promoción de los productos seleccionados", "success")
        return redirect(url_for("promociones"))
    else:
        # Validar que la promoción es futura
        cur.execute("""
            SELECT ID_Promocion 
            FROM promociones 
            WHERE ID_Promocion = %s AND Fecha_Inicial > CURDATE()
        """, (promocion_id,))
        
        futura = cur.fetchone()

        if futura:
            # Solo asignar si es futura
            query = "UPDATE productos SET ID_PromocionFK = %s WHERE ID_Producto IN %s"
            cur.execute(query, (promocion_id, tuple(productos_ids)))
            mysql.connection.commit()
            flash("Promoción asignada correctamente a los productos", "success")
        else:
            flash("No se puede asignar: la promoción no es futura", "error")

        cur.close()
        return redirect(url_for("promociones"))


# -------------------------------------- USUARIOS ----------------------------------------
@app.route('/usuarios')
@admin_required
def usuarios():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM usuarios ORDER BY ID_usuario DESC')
    data = cur.fetchall()

    # Pasar datos ya modificados a la plantilla
    return render_template('Vistas_admin/usuarios.html', usuarios=data)

@app.route('/add_usuario', methods=['POST'])
def add_usuario():
    if request.method == 'POST':  
        nombre = request.form['Nombre']
        apellido = request.form['Apellido']
        documento = request.form['Documento']
        correo = request.form['Correo']
        telefono = request.form['Telefono']
        direccion = request.form['Direccion']
        ciudad = request.form['Ciudad']
        clave = request.form['Clave']
        rol = "Cliente"
        estado = "Activo"

        #  Hashear la contraseña
        clave_hash = generate_password_hash(clave)

        cur = mysql.connection.cursor()
        cur.execute(' CALL insertarusuario(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)',
                        (nombre, apellido, documento, correo, telefono, direccion, ciudad, clave_hash, rol, estado))

        mysql.connection.commit()
        cur.close()
        flash('Usuario agregado correctamente', "success")
        return redirect(url_for('usuarios'))

@app.route('/edit_usuario/<id>')
def edit_usuario(id):
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM usuarios WHERE id_usuario = %s', (id,)) 
    data = cur.fetchone()
    if data:
        user_data = {
            'id': data[0],
            'nombre': data[1],
            'apellido': data[2],
            'documento': data[3],
            'correo': data[4],
            'telefono': data[5],
            'direccion': data[6],
            'ciudad': data[7],
            'clave': data[8]  
        }
        return jsonify(user_data)
    return jsonify({'error': 'Usuario no encontrado'}), 404

@app.route('/update_usuario/<id>', methods=['POST'])
def update_usuario(id):
    if request.method == 'POST':
        nombre = request.form['Nombre']
        apellido = request.form['Apellido']
        documento = request.form['Documento']
        correo = request.form['Correo']
        telefono = request.form['Telefono']
        direccion = request.form['Direccion']
        ciudad = request.form['Ciudad']
        clave = request.form['Clave']
        
        clave_hash = generate_password_hash(clave)

        cur = mysql.connection.cursor()
        cur.execute('''UPDATE usuarios 
                        SET Nombre = %s, Apellido = %s, N_Documento = %s,Correo = %s, 
                            Telefono = %s, Direccion = %s, Ciudad = %s, Clave = %s 
                        WHERE id_usuario = %s''',
                    (nombre, apellido, documento, correo, telefono, direccion, ciudad, clave_hash, id))
        mysql.connection.commit()
        flash('Usuario actualizado correctamente', "success")
        return redirect(url_for('usuarios'))

@app.route('/delete_usuario/<id>', methods=['POST'])
def delete_usuario(id):
    cur = mysql.connection.cursor()
    # Solo actualiza si el usuario está activo
    cur.execute('CALL eliminarusuario(%s)', (id,))
    mysql.connection.commit()

    if cur.rowcount > 0:
        flash('Usuario inactivado correctamente', "success")
    else:
        flash('El usuario ya estaba inactivo o no existe', "warning")

    return redirect(url_for('usuarios'))

# -------------------------------------- VENTAS -----------------------------------------

@app.route('/ventas')
@admin_required
def ventas():
    # Crear un cursor para ejecutar consultas SQL
    cur = mysql.connection.cursor()
    
    # Usar la vista "reporte" para obtener los datos de ventas ya procesados
    cur.execute('''SELECT
                    Num_venta,
                    Fecha,
                    Nombre_Cliente,
                    Apellido_Cliente,
                    SUM(SubTotal_Final) AS Total_Comprado,
                    SUM(Cantidad_p) AS Total_Productos
                    FROM reporte
                    GROUP BY Num_venta
                    ORDER BY Num_venta DESC;
                ''')
    data = cur.fetchall()
    
    # Obtener la lista de usuarios que son clientes para mostrarlos en el formulario
    cur.execute('SELECT ID_Usuario, Nombre, Apellido FROM usuarios WHERE Rol = "Cliente"')
    usuarios = cur.fetchall()
    
    # Obtener la lista de productos disponibles (con stock mayor a 0) para el formulario
    cur.execute('SELECT ID_Producto, Nombre, Precio FROM productos WHERE Stock > 0')
    productos = cur.fetchall()

    cur.close()
    
    return render_template('Vistas_admin/ventas.html', 
                            reportes=data, 
                            usuarios=usuarios, 
                            productos=productos)

@app.route('/add_venta', methods=['POST'])
def add_venta():
    if request.method == 'POST':
        try:
            
            id_usuario = request.form['ID_Usuario']
            productos_data = request.form.getlist('productos[]')
            cantidades = request.form.getlist('cantidades[]')
            
            if not id_usuario:
                flash('Debe seleccionar un cliente', "warning")
                return redirect(url_for('ventas'))
                
            if not productos_data or not cantidades:
                flash('Debe seleccionar al menos un producto', "warning")
                return redirect(url_for('ventas'))
            
            cur = mysql.connection.cursor()

            total_venta = 0
            productos_venta = []
            
            for i, producto_nombre in enumerate(productos_data):
                if producto_nombre and i < len(cantidades) and cantidades[i] and int(cantidades[i]) > 0:
                    # Extraer el nombre del producto del formato "Nombre - $Precio"
                    nombre_producto = producto_nombre.split(' - $')[0].strip()
                    cantidad_solicitada = int(cantidades[i])
                    
                    # Buscar el producto por nombre
                    cur.execute('''
                        SELECT p.ID_Producto, p.Precio, p.Stock, p.Nombre, pr.Descuento
                        FROM productos p
                        LEFT JOIN promociones pr 
                            ON p.ID_PromocionFK = pr.ID_Promocion
                            AND CURDATE() BETWEEN pr.Fecha_Inicial AND pr.Fecha_Final
                        WHERE p.Nombre = %s
                    ''', (nombre_producto,))
                    
                    producto_info = cur.fetchone()
                    
                    if producto_info:
                        producto_id = producto_info[0]
                        precio = int(producto_info[1])
                        stock_disponible = int(producto_info[2])
                        nombre_producto = producto_info[3]
                        descuento = producto_info[4] if producto_info[4] else 0
                        
                        if cantidad_solicitada > stock_disponible:
                            flash(f'Stock insuficiente para {nombre_producto}. Disponible: {stock_disponible}', "warning")
                            return redirect(url_for('ventas'))
                        
                        # Aplicar descuento si existe
                        precio_final = precio - (precio * descuento / 100)
                        subtotal = precio_final * cantidad_solicitada
                        total_venta += subtotal
                        
                        productos_venta.append({
                            'id': producto_id,
                            'cantidad': cantidad_solicitada,
                            'precio_original': precio,
                            'descuento': descuento,
                            'precio_final': precio_final,
                            'subtotal': subtotal,
                            'nombre': nombre_producto
                        })
                    else:
                        flash(f'Producto "{nombre_producto}" no encontrado', "error")
                        return redirect(url_for('ventas'))
            
            if not productos_venta:
                flash('No hay productos válidos en la venta', "error")
                return redirect(url_for('ventas'))
            
            # Insertar en ventas
            cur.execute('''INSERT INTO ventas (ID_UsuarioFK, Fecha, Total) 
                        VALUES (%s, NOW(), %s)''', 
                        (id_usuario, total_venta))
            venta_id = cur.lastrowid
            
            # Insertar detalles de venta
            for producto in productos_venta:
                cur.execute('''
                    INSERT INTO detalles_venta 
                        (ID_VentaFK, ID_ProductoFK, Cantidad_p, SubTotal) 
                    VALUES (%s, %s, %s, %s)
                ''', (venta_id, producto['id'], producto['cantidad'], producto['subtotal']))
                
                # Actualizar stock
                cur.execute('''
                    UPDATE productos 
                    SET Stock = Stock - %s 
                    WHERE ID_Producto = %s
                ''', (producto['cantidad'], producto['id']))
            
            mysql.connection.commit()
            flash('Venta registrada correctamente.', "success")
        
        except Exception as e:
            mysql.connection.rollback()
            flash(f'Error al registrar la venta: {str(e)}', "error")
            print(f"Error detallado: {str(e)}")
        
        finally:
            cur.close()
        
        return redirect(url_for('ventas'))

# -------------------------------------- FACTURA -----------------------------------------
    
@app.route('/factura/<id_venta>')
def factura(id_venta):
    user_id = session['user_id']                # ID del usuario logueado
    rol = session.get('user_role')              # Rol del usuario ('Admin' o 'Cliente')

    cur = mysql.connection.cursor()

    if rol == 'Admin':
        # Admin puede ver cualquier factura
        cur.execute('''
            SELECT Num_venta, Fecha, Nombre_Cliente, Apellido_Cliente,
                    Producto, Precio_Original, Descuento, Precio_Final,
                    Cantidad_p, SubTotal_Final, Total_Venta
            FROM reporte
            WHERE Num_venta = %s
        ''', (id_venta,))
    elif rol == 'Cliente':
        # Cliente solo puede ver sus facturas
        cur.execute('''
            SELECT Num_venta, Fecha, Nombre_Cliente, Apellido_Cliente,
                    Producto, Precio_Original, Descuento, Precio_Final,
                    Cantidad_p, SubTotal_Final, Total_Venta
            FROM reporte
            WHERE Num_venta = %s AND ID_Cliente = %s
        ''', (id_venta, user_id))
    else:
        flash('Rol no reconocido', 'error')
        return redirect(url_for('login'))

    factura_data = cur.fetchall()
    cur.close()

    if factura_data:
        nombre_cliente = factura_data[0][2]
        apellido_cliente = factura_data[0][3]
        fecha = factura_data[0][1]
        total = factura_data[0][10]
    else:
        flash('Factura no encontrada o no autorizada', 'warning')
        return redirect(url_for('compras'))

    # Renderizar según rol
    if rol == 'Admin':
        return render_template('Vistas_admin/factura.html',
                                factura=factura_data,
                                nombre=nombre_cliente,
                                apellido=apellido_cliente,
                                fecha=fecha,
                                id_venta=id_venta,
                                total=total)
    else:  # Cliente
        return render_template('Vista_usuario/factura.html',
                                factura=factura_data,
                                nombre=nombre_cliente,
                                apellido=apellido_cliente,
                                fecha=fecha,
                                id_venta=id_venta,
                                total=total)



# -------------------------------------- CONFIGURACIONES -----------------------------------------
@app.route('/configuracion', methods=['GET'])
@login_required
def configuracion():
    id = session['user_id']                # ID del usuario logueado
    rol = session.get('user_role')         # Rol del usuario ('Admin' o 'Cliente')

    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM usuarios WHERE ID_Usuario = %s', (id,))
    data = cur.fetchone()
    cur.close()

    if not data:
        flash('Usuario no encontrado', 'error')
        return redirect(url_for('login'))

    # Convertimos la tupla en un diccionario (ajusta según el orden de tu tabla)
    usuario = {
        'id_usuario': data[0],
        'nombre': data[1],
        'apellido': data[2],
        'correo': data[3],
        'telefono': data[4],
        'direccion': data[5],
        'ciudad': data[6],
        'clave': data[4]  # Ajusta si tu tabla tiene otro índice
    }

    # Redirigir a la plantilla según el rol
    if rol == 'Admin':
        return render_template('Vistas_admin/configuracion.html', usuario=usuario)
    elif rol == 'Cliente':
        return render_template('Vista_usuario/perfil.html', usuario=usuario, user=id)
    else:
        flash('Rol no reconocido', 'error')
        return redirect(url_for('login'))


@app.route('/actualizar_usuario/<int:id>', methods=['POST'])
@login_required
def actualizar_usuario(id):
    # Obtener datos de sesión
    usuario_id = session['user_id']        # ID del usuario que está logueado
    rol = session.get('user_role')         # Rol del usuario ('Admin' o 'Cliente')

    # Verificar permisos
    if rol == 'Cliente' and usuario_id != id:
        flash('No tienes permiso para actualizar este usuario', 'error')
        return redirect(url_for('configuracion'))

    # Obtener datos del formulario
    nombre = request.form['nombre']
    apellido = request.form['apellido']
    correo = request.form['correo']
    telefono = request.form['telefono']
    direccion = request.form['direccion']
    ciudad = request.form['ciudad']
    clave = request.form['clave'].strip()  # puede venir vacío

    cur = mysql.connection.cursor()

    # Actualizar usuario
    if clave:  # Solo si escribió algo
        clave_hash = generate_password_hash(clave)
        cur.execute("""
            UPDATE usuarios 
            SET Nombre=%s, Apellido=%s, Correo=%s, Telefono=%s, Direccion=%s, Ciudad=%s, Clave=%s
            WHERE ID_Usuario=%s
        """, (nombre, apellido, correo, telefono, direccion, ciudad, clave_hash, id))
    else:  # No actualizar la clave
        cur.execute("""
            UPDATE usuarios 
            SET Nombre=%s, Apellido=%s, Correo=%s, Telefono=%s, Direccion=%s, Ciudad=%s
            WHERE ID_Usuario=%s
        """, (nombre, apellido, correo, telefono, direccion, ciudad, id))

    mysql.connection.commit()
    cur.close()

    flash('Usuario actualizado correctamente', 'success')

    # Redirigir según rol
    return redirect(url_for('configuracion'))

# -------------------------------------- REPORTES -----------------------------------------

@app.route('/reportes')
def reportes():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, fecha_generacion, fecha_inicio, fecha_fin FROM reportes ORDER BY id DESC")
    data = cur.fetchall()
    return render_template("Vistas_admin/reportes.html", reportes=data)


class PDF(FPDF, HTMLMixin):
    """Clase que combina FPDF con HTMLMixin para soportar tablas HTML"""
    pass

# Generar y guardar reporte en la BD
@app.route('/generar_reporte', methods=['POST'])
def generar_reporte():
    fecha_inicio = request.form['fecha_inicio']
    fecha_fin = request.form['fecha_fin']

    # Convertir a objeto datetime y sumar 1 día
    fecha_fin_dt = datetime.strptime(fecha_fin, "%Y-%m-%d") + timedelta(days=1)
    fecha_fin = fecha_fin_dt.strftime("%Y-%m-%d")

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            v.ID_Venta AS Num_venta,
            v.Fecha AS Fecha,
            CONCAT(u.nombre, ' ', u.apellido) AS cliente,
            p.Nombre AS Producto,
            p.Precio AS Precio_Original,
            IFNULL(pr.Descuento, 0) AS Descuento,
            ROUND(dv.SubTotal / NULLIF(dv.Cantidad_p, 0), 0) AS Precio_Final,
            dv.Cantidad_p AS Cantidad_p,
            dv.SubTotal AS SubTotal_Final,
            v.Total AS Total_Venta
        FROM ventas v
        JOIN usuarios u ON u.ID_Usuario = v.ID_UsuarioFK
        JOIN detalles_venta dv ON dv.ID_VentaFK = v.ID_Venta
        JOIN productos p ON p.ID_Producto = dv.ID_ProductoFK
        LEFT JOIN promociones pr 
            ON pr.ID_Promocion = p.ID_PromocionFK 
            AND CURDATE() BETWEEN pr.Fecha_Inicial AND pr.Fecha_Final
            WHERE v.Fecha >= %s AND v.Fecha < %s
            ORDER BY v.Fecha ASC
    """, (fecha_inicio, fecha_fin))

    ventas = cur.fetchall()
    print(ventas)

    # Crear PDF en memoria
    pdf = PDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Reporte de Ventas", ln=True, align="C")
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 10, f"Periodo: {fecha_inicio} a {fecha_fin}", ln=True, align="C")
    pdf.ln(10)

    # Tabla HTML
    html = """
    <table border="1" width="100%" align="center" cellpadding="2">
        <thead>
            <tr bgcolor="#EDB4CD" style="color:white;">
                <th width="20%">Fecha</th>
                <th width="20%">Cliente</th>
                <th width="30%">Prod.</th>
                <th width="15%">Cant.</th>
                <th width="20%">Precio</th>
                <th width="15%">Desc.</th>
                <th width="20%">P. Final</th>
                <th width="20%">Subt.</th>
            </tr>
        </thead>
        <tbody>
    """

    total_general = 0

    for i, v in enumerate(ventas):
        bgcolor = "#f2f2f2" if i % 2 == 0 else "#ffffff"

        # Formatear números estilo Colombia
        precio_original = f"{v[4]:,.0f}".replace(",", ".")
        precio_final = f"{v[6]:,.0f}".replace(",", ".")
        subtotal = f"{v[8]:,.0f}".replace(",", ".")

        html += f"""
        <tr bgcolor="{bgcolor}">
            <td>{v[1]}</td>
            <td>{v[2]}</td>
            <td align="left">{v[3]}</td>
            <td>{v[7]}</td>
            <td>${precio_original}</td>
            <td>{v[5]}%</td>
            <td>${precio_final}</td>
            <td>${subtotal}</td>
        </tr>
        """

        total_general += v[8]

    # Fila final con Total General
    total_general_formatted = f"{total_general:,.0f}".replace(",", ".")
    html += f"""
    <tr bgcolor="#EDB4CD" style="color:white; font-weight:bold;">
        <td colspan="7" align="right">TOTAL GENERAL</td>
        <td>${total_general_formatted}</td>
    </tr>
    """

    html += "</tbody></table>"

    # Renderizar HTML en PDF
    pdf.write_html(html)

    # Exportar PDF como bytes (para BLOB en MySQL)
    pdf_bytes = bytes(pdf.output(dest='S'))

    # Guardar en BD
    cur.execute(
        "INSERT INTO reportes (fecha_inicio, fecha_fin, archivo) VALUES (%s, %s, %s)",
        (fecha_inicio, fecha_fin, pdf_bytes)
    )
    mysql.connection.commit()

    flash("Reporte generado y guardado correctamente", "success")
    return redirect(url_for('reportes'))

#  Descargar PDF desde la BD
@app.route('/descargar_reporte/<int:id>', methods=['GET'])
def descargar_reporte(id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT archivo, fecha_inicio, fecha_fin FROM reportes WHERE id = %s", (id,))
    reporte = cur.fetchone()

    if not reporte:
        flash("El reporte no existe", "error")
        return redirect(url_for('reportes'))

    archivo, fecha_inicio, fecha_fin = reporte
    nombre_archivo = f"reporte_{fecha_inicio}_{fecha_fin}.pdf"

    return send_file(io.BytesIO(archivo), as_attachment=True, download_name=nombre_archivo, mimetype="application/pdf")


#  Previsualizar PDF en navegador
@app.route('/ver_reporte/<int:id>', methods=['GET'])
def ver_reporte(id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT archivo FROM reportes WHERE id = %s", (id,))
    reporte = cur.fetchone()

    if not reporte:
        flash("El reporte no existe", "error")
        return redirect(url_for('reportes'))

    archivo = reporte[0]
    return Response(archivo, mimetype='application/pdf')
# -------------------------------------- DIAGNÓSTICO -----------------------------------------

@app.route('/diagnostico')
def diagnostico():
    template_dir = os.path.abspath(app.template_folder)
    resultado = {
        'directorio_actual': os.getcwd(),
        'ruta_absoluta': template_dir,
        'template_folder': app.template_folder
    }

    # Comprobar si el directorio existe
    if os.path.exists(template_dir):
        resultado['template_dir_existe'] = True
        resultado['contenido_template_dir'] = os.listdir(template_dir)
        
        # Verificar la carpeta Vistas_admin
        vistas_admin_path = os.path.join(template_dir, 'Vistas_admin')
        
        if os.path.exists(vistas_admin_path):
            resultado['vistas_admin_existe'] = True
            resultado['contenido_vistas_admin'] = os.listdir(vistas_admin_path)
        else:
            resultado['vistas_admin_existe'] = False
    else:
        resultado['template_dir_existe'] = False
    
    return jsonify(resultado)

@app.route('/verificar_static')
def verificar_static():
    static_dir = os.path.join(BASE_DIR, 'static')
    return jsonify({
        "static_dir": static_dir,
        "static_existe": os.path.exists(static_dir),
        "contenido_static": os.listdir(static_dir) if os.path.exists(static_dir) else []
    })

if __name__ == '__main__':
    # Imprime información útil de depuración al iniciar
    print(f"Directorio de trabajo actual: {os.getcwd()}")
    print(f"Directorio de templates (ruta absoluta): {os.path.abspath(app.template_folder)}")
    print(f"Directorio de templates existe: {os.path.exists(os.path.abspath(app.template_folder))}")
    
    app.run(debug=True, port=5000  )